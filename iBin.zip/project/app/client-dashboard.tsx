import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Bell, History, Settings, LogOut, AlertTriangle } from 'lucide-react-native';
import CircularProgress from '@/components/CircularProgress';
import { Compartment, MOCK_BINS, updateCompartmentLevel, createHistoryEvent } from '@/utils/mockData';
import { scheduleNotification } from '@/utils/notifications';

export default function ClientDashboard() {
  const router = useRouter();
  const [compartments, setCompartments] = useState<Compartment[]>(MOCK_BINS[0].compartments);
  const [notifications, setNotifications] = useState<string[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCompartments((prev) =>
        prev.map((comp) => {
          const updated = updateCompartmentLevel(comp);

          if (updated.level > updated.threshold && comp.level <= updated.threshold) {
            const message = `${updated.name} reached ${Math.round(updated.level)}% capacity`;
            setNotifications((n) => [message, ...n.slice(0, 9)]);
            scheduleNotification('Waste Bin Alert', message);
          }

          if (updated.jam && !comp.jam) {
            const message = `Jam detected in ${updated.name} compartment`;
            setNotifications((n) => [message, ...n.slice(0, 9)]);
            scheduleNotification('Waste Bin Alert', message);
          }

          return updated;
        })
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getStatus = () => {
    const hasJam = compartments.some((c) => c.jam);
    const overThreshold = compartments.some((c) => c.level > c.threshold);

    if (hasJam) return { text: 'Jam Detected', color: '#F44336' };
    if (overThreshold) return { text: 'Attention Required', color: '#FF9800' };
    return { text: 'No Issues', color: '#4CAF50' };
  };

  const status = getStatus();

  const showNotifications = () => {
    if (notifications.length === 0) {
      Alert.alert('Notifications', 'No recent notifications');
    } else {
      Alert.alert(
        'Recent Notifications',
        notifications.slice(0, 5).join('\n\n'),
        [{ text: 'OK' }]
      );
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Client Dashboard</Text>
          <View style={styles.statusContainer}>
            <View style={[styles.statusDot, { backgroundColor: status.color }]} />
            <Text style={[styles.statusText, { color: status.color }]}>{status.text}</Text>
          </View>
        </View>
        <View style={styles.headerButtons}>
          <TouchableOpacity style={styles.iconButton} onPress={showNotifications}>
            <Bell size={24} color="#2E7D32" />
            {notifications.length > 0 && <View style={styles.badge} />}
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => router.push('/(tabs)')}
          >
            <LogOut size={24} color="#2E7D32" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.gridContainer}>
          {compartments.map((comp) => (
            <View key={comp.id} style={styles.card}>
              <Text style={styles.cardTitle}>{comp.name}</Text>
              <CircularProgress
                percentage={comp.level}
                color={comp.color}
                size={100}
                strokeWidth={10}
              />
              {comp.jam && (
                <View style={styles.jamWarning}>
                  <AlertTriangle size={16} color="#F44336" />
                  <Text style={styles.jamText}>Jam Detected</Text>
                </View>
              )}
              <Text style={styles.thresholdText}>Threshold: {comp.threshold}%</Text>
            </View>
          ))}
        </View>

        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/history')}
          >
            <History size={20} color="#FFFFFF" />
            <Text style={styles.actionButtonText}>View History</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, styles.secondaryButton]}
            onPress={() =>
              Alert.alert(
                'Settings (View Only)',
                compartments
                  .map((c) => `${c.name} Threshold: ${c.threshold}%`)
                  .join('\n')
              )
            }
          >
            <Settings size={20} color="#2E7D32" />
            <Text style={[styles.actionButtonText, styles.secondaryButtonText]}>
              Settings
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  statusText: {
    fontSize: 14,
    fontWeight: '500',
  },
  headerButtons: {
    flexDirection: 'row',
  },
  iconButton: {
    padding: 8,
    marginLeft: 8,
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#F44336',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  card: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  jamWarning: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    backgroundColor: '#FFEBEE',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  jamText: {
    fontSize: 12,
    color: '#F44336',
    marginLeft: 4,
    fontWeight: '500',
  },
  thresholdText: {
    fontSize: 12,
    color: '#666',
    marginTop: 8,
  },
  actionButtons: {
    marginTop: 8,
  },
  actionButton: {
    backgroundColor: '#2E7D32',
    borderRadius: 12,
    paddingVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  secondaryButton: {
    backgroundColor: '#FFFFFF',
    borderWidth: 2,
    borderColor: '#2E7D32',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  secondaryButtonText: {
    color: '#2E7D32',
  },
});
