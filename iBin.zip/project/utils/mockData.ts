export interface Compartment {
  id: string;
  name: string;
  level: number;
  threshold: number;
  jam: boolean;
  color: string;
}

export interface WasteBin {
  id: string;
  name: string;
  compartments: Compartment[];
}

export interface HistoryEvent {
  id: string;
  timestamp: Date;
  compartment: string;
  message: string;
  type: 'warning' | 'info' | 'error';
}

export const MOCK_BINS: WasteBin[] = [
  {
    id: 'bin-a',
    name: 'Bin A',
    compartments: [
      { id: 'plastic', name: 'Plastic', level: 45, threshold: 80, jam: false, color: '#2196F3' },
      { id: 'paper', name: 'Paper', level: 62, threshold: 80, jam: false, color: '#8BC34A' },
      { id: 'metal', name: 'Metal', level: 30, threshold: 80, jam: false, color: '#FF9800' },
      { id: 'others', name: 'Others', level: 55, threshold: 80, jam: false, color: '#9E9E9E' },
    ],
  },
  {
    id: 'bin-b',
    name: 'Bin B',
    compartments: [
      { id: 'plastic', name: 'Plastic', level: 78, threshold: 80, jam: false, color: '#2196F3' },
      { id: 'paper', name: 'Paper', level: 34, threshold: 80, jam: false, color: '#8BC34A' },
      { id: 'metal', name: 'Metal', level: 88, threshold: 80, jam: true, color: '#FF9800' },
      { id: 'others', name: 'Others', level: 41, threshold: 80, jam: false, color: '#9E9E9E' },
    ],
  },
  {
    id: 'bin-c',
    name: 'Bin C',
    compartments: [
      { id: 'plastic', name: 'Plastic', level: 20, threshold: 80, jam: false, color: '#2196F3' },
      { id: 'paper', name: 'Paper', level: 91, threshold: 80, jam: false, color: '#8BC34A' },
      { id: 'metal', name: 'Metal', level: 15, threshold: 80, jam: false, color: '#FF9800' },
      { id: 'others', name: 'Others', level: 68, threshold: 80, jam: false, color: '#9E9E9E' },
    ],
  },
];

export const INITIAL_HISTORY: HistoryEvent[] = [
  {
    id: '1',
    timestamp: new Date(Date.now() - 3600000),
    compartment: 'Plastic',
    message: 'Plastic reached 80% capacity',
    type: 'warning',
  },
  {
    id: '2',
    timestamp: new Date(Date.now() - 7200000),
    compartment: 'Metal',
    message: 'Metal compartment emptied',
    type: 'info',
  },
  {
    id: '3',
    timestamp: new Date(Date.now() - 10800000),
    compartment: 'Paper',
    message: 'Jam detected in Paper compartment',
    type: 'error',
  },
];

export function updateCompartmentLevel(compartment: Compartment): Compartment {
  const change = Math.floor(Math.random() * 21) - 10;
  const newLevel = Math.max(0, Math.min(100, compartment.level + change));
  const jamProbability = newLevel > 85 ? 0.1 : 0.02;
  const newJam = Math.random() < jamProbability;

  return {
    ...compartment,
    level: newLevel,
    jam: newJam,
  };
}

export function createHistoryEvent(
  compartment: string,
  message: string,
  type: 'warning' | 'info' | 'error'
): HistoryEvent {
  return {
    id: Date.now().toString(),
    timestamp: new Date(),
    compartment,
    message,
    type,
  };
}
